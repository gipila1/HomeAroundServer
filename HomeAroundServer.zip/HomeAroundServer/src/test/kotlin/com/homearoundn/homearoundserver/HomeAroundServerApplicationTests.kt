package com.homearoundn.homearoundserver

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HomeAroundServerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
