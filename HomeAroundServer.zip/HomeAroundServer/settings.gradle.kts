rootProject.name = "HomeAroundServer"
